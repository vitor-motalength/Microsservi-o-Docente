package ucsal.edu.com.ContextoDocente;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContextoDocenteApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContextoDocenteApplication.class, args);
	}

}
